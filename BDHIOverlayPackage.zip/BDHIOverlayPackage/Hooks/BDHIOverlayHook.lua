-- BDHI Overlay: DCS GameGUI loader
local lfs = require('lfs')
local path = lfs.writedir() .. 'Scripts\\BDHIOverlay\\BDHIOverlay.lua'
local ok, err = pcall(dofile, path)
if not ok then
    net.log('[BDHIOverlay] Loader error: ' .. tostring(err))
end
