-- SH-60B-style Bearing-Distance-Heading-Indicator
-- by Kromehawk (rotorsimdev@gmail.com)
-- Version 0.9b
-- BDHI Overlay: compass, TACAN, and course display with Ctrl+Shift+F12 toggle

--Main init function
local function initialize()
    local lfs = require('lfs')
    local DialogLoader = require('DialogLoader')
    local SkinUtils = require('SkinUtils')
    local Skin = require('Skin')

    local root = lfs.writedir() .. 'Scripts\\BDHIOverlay\\'
    local hotkey = 'Ctrl+Shift+F12'
    local gaugeSize = 200
    local windowX, windowY = 80, 100
	
	--Store position of gauge on screen between sessions
	local positionFile = root .. 'BDHIOverlayPosition.txt'

	local function loadPosition()
		local file = io.open(positionFile, 'r')
		if not file then return end

		local x = tonumber(file:read('*l'))
		local y = tonumber(file:read('*l'))
		file:close()

		if x and y then
			windowX, windowY = x, y
		end
	end

	local function savePosition(x, y)
		local file, err = io.open(positionFile, 'w')
		if not file then
			net.log('[BDHIOverlay] Position save error: ' .. tostring(err))
			return
		end

		file:write(tostring(x), '\n', tostring(y), '\n')
		file:close()
	end

	loadPosition()
	
	--Variabe declarations
    local window = nil
    local panel = nil
	local compassWidget = nil
	local dmeHundredsWidget = nil
	local dmeTensWidget = nil
	local dmeOnesWidget = nil
	local dmeFractionWidget = nil
	local tacanNeedleWidget = nil
    local cdiCardWidget = nil
    local cdiBarWidget = nil
    local toFlagWidget = nil
    local fromFlagWidget = nil
    local crsKnobWidget = nil
    local courseDisplayWidget = nil
    local selectedCourse = 0
    local magneticHeading = 0
    local channelWidgets = {}
    local dmeFlagWidget = nil
    local channel = {0, 5, 5} --Channels are three digits with a band
    local band = 'X'
    local stationValid = false
    local shipTestFrames = 119 -- first lookup immediately
    local stationBearing = nil
    local cdiAngle = 0
    local cdiBarWidth = 14 * gaugeSize / 1254
    local cdiBarHeight = 418 * gaugeSize / 1254
    local cdiDotSpacing = 82 * gaugeSize / 1254
    local cdiMaxDeflection = 2 * cdiDotSpacing + 6

	--Course deviation indicator function
    local function updateCdi()
        cdiAngle = (magneticHeading - selectedCourse) % 360
        if cdiCardWidget then cdiCardWidget:setAngle(cdiAngle) end
        if toFlagWidget then toFlagWidget:setAngle(cdiAngle) end
        if fromFlagWidget then fromFlagWidget:setAngle(cdiAngle) end

        local toStation = false
        local fromStation = false
        local deviation = 0
        if stationValid and stationBearing then
            local bearingDifference = ((stationBearing - selectedCourse + 180) % 360) - 180
            toStation = math.abs(bearingDifference) < 89.5
            fromStation = math.abs(bearingDifference) > 90.5
            if toStation then
                deviation = bearingDifference
            elseif fromStation then
                deviation = ((stationBearing + 180 - selectedCourse + 180) % 360) - 180
            end
        end

        if toFlagWidget then toFlagWidget:setVisible(toStation) end
        if fromFlagWidget then fromFlagWidget:setVisible(fromStation) end

        if cdiBarWidget then
            local magnitude = math.abs(deviation)
            local dotLimit = 2 * cdiDotSpacing
            local travel = math.min(magnitude, 10) / 10 * dotLimit
            if magnitude > 10 then
                travel = travel + math.min((magnitude - 10) / 2, 1) * (cdiMaxDeflection - dotLimit)
            end
            local deflection = (deviation < 0 and -1 or 1) * travel
            local angleRad = math.rad(cdiAngle)
            local offsetX = deflection * math.cos(angleRad)
            local offsetY = -deflection * math.sin(angleRad)
            cdiBarWidget:setBounds(
                (gaugeSize - cdiBarWidth) / 2 + offsetX,
                (gaugeSize - cdiBarHeight) / 2 + offsetY,
                cdiBarWidth, cdiBarHeight
            )
            cdiBarWidget:setAngle(cdiAngle)
        end
    end

	--Update CDI and course window with the delta from the mouse wheel
    local function updateCourse(delta)
        selectedCourse = (selectedCourse + delta) % 360
        updateCdi()
        crsKnobWidget:setAngle(selectedCourse)
        courseDisplayWidget:setText(string.format('%03d', selectedCourse))
    end

	--Function to combine the parts of the channel into a single number
    local function channelNumber()
        return channel[1] * 100 + channel[2] * 10 + channel[3]
    end

    local function refreshChannelText()
        for i = 1, 3 do
            if channelWidgets[i] then channelWidgets[i]:setText(tostring(channel[i])) end
        end
        if channelWidgets[4] then channelWidgets[4]:setText(band) end
    end

	--If navigation data is not available on the selected station, take action
    local function invalidateStation()
        stationValid = false
        stationBearing = nil
        updateCdi()
        if dmeFlagWidget then dmeFlagWidget:setVisible(true) end
    end

    local function changeChannelDigit(index, delta)
        if index == 4 then
            band = (band == 'X') and 'Y' or 'X'
        else
            local maxDigit = (index == 1) and 1 or 9
            channel[index] = (channel[index] + delta + maxDigit + 1) % (maxDigit + 1)
        end
        refreshChannelText()
        invalidateStation()
        shipTestFrames = 119
    end
    local originalSkin = nil
    local hiddenSkin = Skin.windowSkinChatMin()
    local isHidden = false

	--Function to simplify logging/debugging
    local function log(message)
        net.log('[BDHIOverlay] ' .. tostring(message))
    end

    local function createWindow()
        if window then return end
        window = assert(DialogLoader.spawnDialogFromFile(root .. 'BDHIOverlay.dlg'))
        panel = assert(window.Box)

        local background = assert(panel.backgroundWidget)
        local compass = assert(panel.compassWidget)
		local needle = assert(panel.tacanNeedleWidget)
		dmeHundredsWidget = assert(panel.dmeHundredsWidget)
		dmeTensWidget = assert(panel.dmeTensWidget)
		dmeOnesWidget = assert(panel.dmeOnesWidget)
		dmeFractionWidget = assert(panel.dmeFractionWidget)
        dmeFlagWidget = assert(panel.dmeFlagWidget)
        cdiCardWidget = assert(panel.cdiCardWidget)
        cdiBarWidget = assert(panel.cdiBarWidget)
        toFlagWidget = assert(panel.toFlagWidget)
        fromFlagWidget = assert(panel.fromFlagWidget)
        crsKnobWidget = assert(panel.crsKnobWidget)
        courseDisplayWidget = assert(panel.courseDisplayWidget)
        for i, name in ipairs({'channelHundredsWidget', 'channelTensWidget', 'channelOnesWidget', 'channelBandWidget'}) do
            local widget = assert(panel[name])
            channelWidgets[i] = widget
            widget:addMouseDownCallback(function(self, x, y, button)
                if button == 1 then
                    changeChannelDigit(i, 1)
                elseif button == 3 then
                    changeChannelDigit(i, -1)
                end
            end)
        end
        refreshChannelText()
        dmeFlagWidget:setSkin(SkinUtils.setStaticPicture(root .. 'dme-flag.png', dmeFlagWidget:getSkin()))
        invalidateStation()
		
		compassWidget = compass
		tacanNeedleWidget = needle
		
        background:setSkin(SkinUtils.setStaticPicture(root .. 'bdhi-bg.png', background:getSkin()))
        
		compass:setSkin(SkinUtils.setStaticPicture(root .. 'compass-card.png', compass:getSkin()))
		
		needle:setSkin(SkinUtils.setStaticPicture(root .. 'tacan-needle.png', needle:getSkin()))
		
        window:setBounds(windowX, windowY, gaugeSize, gaugeSize + 24)
		
		window:addPositionCallback(function(self)
			local x, y = self:getPosition()
			windowX, windowY = x, y
			savePosition(x, y)
		end)
		
        panel:setBounds(0, 0, gaugeSize, gaugeSize)
        
		background:setBounds(0, 0, gaugeSize, gaugeSize)
        
		compass:setBounds(0, 0, gaugeSize, gaugeSize)
		compass:setPivotPoint(gaugeSize / 2, gaugeSize / 2)
		
		needle:setBounds(0, 0, gaugeSize, gaugeSize)
		needle:setPivotPoint(gaugeSize / 2, gaugeSize / 2)
		needle:setAngle(0)

        cdiCardWidget:setSkin(SkinUtils.setStaticPicture(root .. 'cdi-card.png', cdiCardWidget:getSkin()))
        cdiCardWidget:setBounds(0, 0, gaugeSize, gaugeSize)
        cdiCardWidget:setPivotPoint(gaugeSize / 2, gaugeSize / 2)
        cdiCardWidget:setAngle(0)

        cdiBarWidget:setSkin(SkinUtils.setStaticPicture(root .. 'cdi-bar.png', cdiBarWidget:getSkin()))
        cdiBarWidget:setPivotPoint(cdiBarWidth / 2, cdiBarHeight / 2)
        toFlagWidget:setSkin(SkinUtils.setStaticPicture(root .. 'to-flag.png', toFlagWidget:getSkin()))
        fromFlagWidget:setSkin(SkinUtils.setStaticPicture(root .. 'from-flag.png', fromFlagWidget:getSkin()))
        for _, flag in ipairs({toFlagWidget, fromFlagWidget}) do
            flag:setBounds(0, 0, gaugeSize, gaugeSize)
            flag:setPivotPoint(gaugeSize / 2, gaugeSize / 2)
            flag:setVisible(false)
        end
        updateCdi()

        crsKnobWidget:setSkin(SkinUtils.setStaticPicture(root .. 'crs-knob.png', crsKnobWidget:getSkin()))
        crsKnobWidget:setBounds(155, 160, 36, 36)
        crsKnobWidget:setPivotPoint(18, 18)
        crsKnobWidget:setAngle(0)
        courseDisplayWidget:setText(string.format('%03d', selectedCourse))

        if type(crsKnobWidget.addMouseWheelCallback) == 'function' then
            crsKnobWidget:addMouseWheelCallback(function(self, x, y, delta)
				if type(delta) == 'number' and delta ~= 0 then
					updateCourse(delta > 0 and 1 or -1)
				end
			end)
        else
            log('CRS knob mouse-wheel callback unavailable')
        end

        originalSkin = window:getSkin()
		window:setText('BDHI Overlay (' .. hotkey .. ')')
        window:setVisible(true)
        window:setHasCursor(true)

        -- Got this bit from Bailey's MFK Overlay, which can be found
		-- at https://github.com/asherao/kiowa-mfk-overlay
        local function setHidden(hidden)
            isHidden = hidden
            if hidden then
                panel:setVisible(false)
                window:setSkin(hiddenSkin)
                window:setHasCursor(false)
            else
                window:setVisible(true)
                window:setSkin(originalSkin)
                panel:setVisible(true)
                window:setHasCursor(true)
            end
            log(hidden and 'hidden' or 'shown')
        end

        window:addHotKeyCallback(hotkey, function()
            setHidden(not isHidden)
        end)
        setHidden(true)
        log('Window created; hotkey=' .. hotkey)
    end
	
	local function updateCompass()
		if not compassWidget then return end

		-- DCS returns magnetic heading in radians.
		local headingRad = Export.LoGetMagneticYaw()

		if type(headingRad) ~= 'number' then return end

		-- Convert radians to degrees and normalize to 0-360.
		local headingDeg = (math.deg(headingRad) % 360)

		-- Compass card rotates opposite aircraft heading.
		compassWidget:setAngle(headingDeg)
        magneticHeading = headingDeg
        if cdiCardWidget then
            updateCdi()
        end
	end

	-- Cache the ship position; update the needle from current ownship data
	-- on every simulation frame, without querying mission scripting each frame.
	-- shipTestFrames is initialized above so channel changes can trigger immediate lookup.
	
	-- DCS uses a North-Up-East coordinate frame instead of a more classic NED or ENU
	local shipX, shipZ = nil, nil

	--This is the main TACAN functionality here
	local function testShipPosition()
		shipTestFrames = shipTestFrames + 1
		local refreshShip = shipTestFrames >= 10 --Update the ship's location every 10 frames
		if refreshShip then
			shipTestFrames = 0
			local number = channelNumber()
			if number < 1 or number > 126 then
				shipX, shipZ = nil, nil
				invalidateStation()
				return
			end
			local ok, result, success = pcall(
				net.dostring_in,
				"scripting",
                string.format([[
                    local ship = Unit.getByName(%q) or Unit.getByName(%q)
					if not ship or not ship:isExist() then
						return "SHIP_NOT_FOUND"
					end
					local p = ship:getPoint()
					return string.format("SHIP|%%.6f|%%.6f|%%.6f", p.x, p.y, p.z)
                ]], 'Naval-' .. tostring(channelNumber()) .. band,
                    'Naval-' .. string.format('%03d', channelNumber()) .. band)
            )
			if not ok then
				log("NAV bridge error: " .. tostring(result))
                shipX, shipZ = nil, nil
                invalidateStation()
                return
			end
			if success ~= true or type(result) ~= "string" then
				log("NAV ship lookup: " .. tostring(result))
                shipX, shipZ = nil, nil
                invalidateStation()
                return
			end
			local sx, sy, sz = result:match(
				"^SHIP|([%d%.%-]+)|([%d%.%-]+)|([%d%.%-]+)$"
			)
			sx, sz = tonumber(sx), tonumber(sz)
			if not sx or not sz or not tonumber(sy) then
				log("NAV ship lookup: " .. result)
                shipX, shipZ = nil, nil
                invalidateStation()
                return
			end
            shipX, shipZ = sx, sz
            stationValid = true
            if dmeFlagWidget then dmeFlagWidget:setVisible(false) end
		end

        if not stationValid or not shipX or not shipZ then return end

		-- Get where we are and what our heading is
		local selfData = Export.LoGetSelfData()
		local magYaw = Export.LoGetMagneticYaw()
		if not selfData or not selfData.Position
			or type(selfData.Heading) ~= "number"
			or type(magYaw) ~= "number" then
			if refreshShip then log("NAV: Ownship data unavailable") end
			return
		end

		local own = selfData.Position
		-- Preserve the coordinate convention verified in the flight test.
		local north = shipX - own.x
		local east  = shipZ - own.z
		local trueBearing = math.deg(math.atan2(east, north)) % 360
		local trueHeading = math.deg(selfData.Heading) % 360
		local magneticHeading = math.deg(magYaw) % 360
		local variation = ((trueHeading - magneticHeading + 180) % 360) - 180
		local magneticBearing = (trueBearing - variation) % 360
        stationBearing = magneticBearing
        updateCdi()
		local relativeBearing = (magneticBearing - magneticHeading) % 360
		local needleAngle = (360 - relativeBearing) % 360

		-- Rotate every frame, including between ship position lookups.
		if tacanNeedleWidget then
			tacanNeedleWidget:setAngle(needleAngle)
		end

		-- DME and diagnostic logging remain on the slower update cycle.
		if refreshShip then
			local distanceNM = math.sqrt(north * north + east * east) / 1852
			if dmeFractionWidget then
				local dmeText = string.format("%.1f", distanceNM)
				local integer, fraction = dmeText:match("^(%d+)%.(%d)$")
				if integer then
					-- The display has three integer-digit positions.
					integer = integer:sub(-3)
					dmeHundredsWidget:setText(#integer >= 3 and integer:sub(-3, -3) or "")
					dmeTensWidget:setText(#integer >= 2 and integer:sub(-2, -2) or "")
					dmeOnesWidget:setText(integer:sub(-1))
					dmeFractionWidget:setText("." .. fraction)
				end
			end
			log(string.format(
				"NAV: own=(%.1f,%.1f) ship=(%.1f,%.1f) " ..
				"DME=%.2f NM BRG_TRUE=%.1f BRG_MAG=%.1f " ..
				"HDG_TRUE=%.1f HDG_MAG=%.1f VAR=%.1f " ..
				"REL=%.1f NEEDLE=%.1f",
				own.x, own.z, shipX, shipZ, distanceNM,
				trueBearing, magneticBearing, trueHeading,
				magneticHeading, variation, relativeBearing, needleAngle
			))
		end
	end


	-- Consider this the main loop...
    local handler = {}
    function handler.onSimulationFrame()
		if not window then
			local ok, err = pcall(createWindow)
			if not ok then
				log('Window creation error: ' .. tostring(err))
			end
		end

		if compassWidget then
			local ok, err = pcall(updateCompass)
			if not ok then
				log('Compass update error: ' .. tostring(err))
			end
		end
		
		local ok, err = pcall(testShipPosition)
		if not ok then
			log("Ship position test error: " .. tostring(err))
		end
	end
    DCS.setUserCallbacks(handler)
    log('Hook initialized')
end

local ok, err = pcall(initialize)
if not ok then net.log('[BDHIOverlay] Initialization error: ' .. tostring(err)) end
